A Pen created at CodePen.io. You can find this one at http://codepen.io/alcoven/pen/MwJNyG.

 Used a blur to achieve this optical merge of shapes.
Just a test. Have been trying to emulate this gooey effect without SVG or JS for a while now. Finally making headway.

Credits to Lucas Bebber for the original idea of using blur this way